import React from 'react'

class LoginForm extends React.Component {
    handleClick = () => {
        const { handleLoginClick } = this.props
        handleLoginClick(true)
    }
    render() {
        const { onButtonClick } = this.props
        return (
            <div className="LoginForm">
                Форма логина
                <br />
                <input type="text" placeholder="Введите имя" />
                <br />
                <button onClick={onButtonClick}>Войти</button>
            </div>
        )
    }
}
export default LoginForm
