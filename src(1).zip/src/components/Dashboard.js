import React from 'react'
import Navigator from './Navigator'
import Students from './Tables/Students'
import CourseWork from './Tables/CourseWork'
class Dashboard extends React.Component {
    handleClick = () => {
        const { handleLoginClick } = this.props
        handleLoginClick(false)
    }

    render() {
        return (
            <div className="Dashboard">
                <button onClick={this.handleClick}>Выйти</button>
                <h5> {this.props.message}</h5>
            </div>
        )
    }
}
export default Dashboard
