import React from 'react'
import PersonIcon from '@material-ui/icons/Person'
import GroupIcon from '@material-ui/icons/Group'
import DateRangeIcon from '@material-ui/icons/DateRange'
import Students from './Tables/Students'
import CourseWork from './Tables/CourseWork'

class Navigator extends React.Component {
    state = {
        id: 0,
    }
    sendUserId = (userId) => {
        this.sendValue(<CourseWork id={userId} />)
    }
    sendValue = (data) => {
        this.props.sendValue(data)
    }

    render() {
        const buttonArray = [
            {
                text: 'ФИО',
                icon: <PersonIcon />,
                data: 'Георгиева Екатерина Сергеевна',
            },
            {
                text: 'Группа',
                icon: <GroupIcon />,
                data: 'Ир1-17',
            },
            {
                text: 'Возраст',
                icon: <DateRangeIcon />,
                data: '19',
            },
            {
                text: 'Студенты',
                icon: <GroupIcon />,
                data: <Students userId={this.sendUserId} />,
            },
            {
                text: 'Курсовые',
                icon: <GroupIcon />,
                data: <CourseWork />,
            },
        ]

        return (
            <div className="Navigator">
                {buttonArray.map((button, i) => (
                    <div>
                        <button
                            onClick={() => {
                                this.sendValue(button.data)
                            }}
                        >
                            {button.icon}
                            {button.text}
                        </button>
                    </div>
                ))}
            </div>
        )
    }
}
export default Navigator
