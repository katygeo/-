import logo from './logo.svg'
import './App.css'
import React from 'react'
import LoginForm from './components/LoginForm'
import Dashboard from './components/Dashboard'
import Navigator from './components/Navigator'
import 'antd/dist/antd.css'

class App extends React.Component {
    state = {
        isLoggedIn: false,
        message: '',
    }
    handleLoginClick = (param) => {
        this.setState({ isLoggedIn: param })
    }
    callbackFunction = (childData) => {
        this.setState({ message: childData })
    }
    render() {
        return (
            <div className="App">
                {this.state.isLoggedIn ? (
                    <div className="MainScreen">
                        <Navigator sendValue={this.callbackFunction} />
                        <Dashboard
                            handleLoginClick={this.handleLoginClick}
                            message={this.state.message}
                        />
                    </div>
                ) : (
                    <LoginForm onButtonClick={this.handleLoginClick} />
                )}
            </div>
        )
    }
}

export default App
