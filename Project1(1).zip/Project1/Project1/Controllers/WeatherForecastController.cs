﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Text;
using System.Text.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace Project1.Controllers
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class CourseWork
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
        public string body { get; set; }
    }
    public class StudentsController : Controller
    {
        private readonly Student[] Students = new[]
        {
            new Student
            {
                Id=1,
                Name="Leanne Graham"
            },
            new Student
            {
                Id=2,
                Name="Ervin Howell"
            },
            new Student
            {
                Id=3,
                Name="Clementine Bauch"
            },
            new Student
            {
                Id=4,
                Name="Patricia Lebsack"
            },
            new Student
            {
                Id=5,
                Name="Chelsey Dietrich"
            },
        };
        private readonly ILogger<StudentsController> _logger;
        public StudentsController(ILogger<StudentsController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public ActionResult Get()
        {
            return Json(Students);
        }
    }

    public class CourseWorksController : Controller
    {
        private readonly CourseWork[] CourseWorks = new[]
        {
            new CourseWork
            {
                userId= 1,
                id=1,
                title="sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                body="quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
            },
             new CourseWork
            {
                userId= 2,
                id=2,
                title="sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                body="quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
            },
              new CourseWork
            {
                userId= 3,
                id=3,
                title="sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                body="quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
            },
               new CourseWork
            {
                userId= 4,
                id=4,
                title="sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                body="quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
            },
                new CourseWork
            {
                userId= 5,
                id=5,
                title="sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
                body="quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
            },
        };
        private readonly ILogger<CourseWorksController> _logger;
        public CourseWorksController(ILogger<CourseWorksController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public ActionResult Get()
        {
            return Json(CourseWorks);
        }
    }
}
