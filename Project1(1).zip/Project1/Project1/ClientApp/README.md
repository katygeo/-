###Запуск проекта:

>yarn start

##Для тех кто добавляет в свой проект Mobx:

#Сначала извлекаем все исходники

>yarn eject

#потом

>yarn add @babel/plugin-proposal-decorators mobx mobx-react mobx-react-devtools --dev