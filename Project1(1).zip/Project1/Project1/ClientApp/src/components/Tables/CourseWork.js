import React from 'react';
import { Table } from 'antd';
import { observable } from 'mobx';
import { inject } from 'mobx-react';
const url = 'CourseWorks/Get';

const columns = [
  {
    title: 'userId',
    dataIndex: 'userId',
    key: 'userId',
  },
  {
    title: 'Id',
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: 'Название',
    dataIndex: 'title',
    key: 'title',
  },
  {
    title: 'Описание',
    dataIndex: 'body',
    key: 'body',
  },
];
@inject('MainStore')
class CourseWork extends React.Component {
  state = {
    doc: [],
    error: '',
  };

  componentDidMount = async () => {
    let docs = [];
    try {
      let result;
      if (this.props.id != undefined) {
        result = await fetch(url + '?userId=' + this.props.id);
      } else {
        result = await fetch(url);
      }
      const docs = await result.json();
      this.setState({
        doc: docs,
      });
    } catch (err) {
      this.setState({
        error: 'Ошибка получения данных',
      });
    }
  };

  render() {
    const { MainStore } = this.props;
    const { error } = this.state;
    const { doc } = this.state;

    return (
      <div className>
        <h1>Курсовые работы</h1>
        <h2>{error}</h2>
        <div className='table-wrapper'>
          <Table
            dataSource={doc}
            columns={columns}
            size='small'
            rowClassName={(record, index) =>
               MainStore.workCount.indexOf(record.id) != -1 ? 'table-row-dark' : 'table-row-light'
            }
            onRow={(record, rowIndex) => {
                      
              return {
                    
                onClick: (event) => {
                  this.props.MainStore.AddWatchedWork(record.id);
                   console.log(record.id)
                  
                },
              };
            }}
          />
        </div>
      </div>
    );
  }
}

export default CourseWork;
