import React from 'react';
import { Table } from 'antd';
import { observable } from 'mobx';
import { inject, observer } from 'mobx-react';

const url = 'Students/Get';

const columns = [
  {
    title: 'Id',
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: 'Имя',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
  },
  {
    title: 'Телефон',
    dataIndex: 'phone',
    key: 'phone',
  },
];
@inject('MainStore')
@observer
class Students extends React.Component {
  state = {
    stud: [],
    error: '',
  };

  componentDidMount = async () => {
    try {
      const result = await fetch(url);
      const studs = await result.json();
      this.setState({
        stud: studs,
      });
    } catch (err) {
      this.setState({
        error: 'Ошибка получения данных',
      });
    }
  };

  render() {
    const { MainStore } = this.props;
    const { error } = this.state;
    const { stud } = this.state;
    return (
      <div>
        <h1>Список Студентов</h1>
        <h2>{error}</h2>
        <div className='table-wrapper'>
          <Table
            dataSource={stud}
            columns={columns}
            size='small'
            rowClassName={(record, index) =>
              MainStore.students.indexOf(record.id) != -1
                ? 'table-row-dark'
                : 'table-row-light'
            }
            onRow={(record, rowIndex) => {
              return {
                onClick: (event) => {
                  this.props.setStudentId(record.id, true);
                },
              };
            }}
          />
        </div>
      </div>
    );
  }
}

export default Students;
