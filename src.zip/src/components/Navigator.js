import React from 'react'
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import GroupIcon from '@material-ui/icons/Group';
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';

const buttonArray=[
    {
        text:'ФИО',
        icon:<AccountCircleIcon/>,
        title:'Георгиева Екатерина Сергеевна',
    },
    {
        text:'Группа',
        icon:<GroupIcon/>,
        title:'Ир1-17',
    },
    {
        text:'Возраст',
        icon:<PermContactCalendarIcon/>,
        title:'19',
    },
];


class Navigator extends React.Component {
  sendValue = (title) => {
      console.log(title);
      this.props.sendValue(title);
  }
    render() {
        return (
            <div className="Navigator">
                {buttonArray.map((button,i) => (
                    <div>
                        <button onClick={() => {this.sendValue(button.title)}}>
                            {button.icon}
                            {button.text}

                        </button>
                    </div>
                ))}
            </div>
        )
    }
}
export default Navigator
