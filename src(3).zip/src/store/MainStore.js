import { observable, action, makeObservable } from 'mobx';

export default class MainStore {
  constructor() {
    makeObservable(this);
  }

  @observable userFullName = 'Иванов Иван';
  @observable students = [];
  @observable workCount = [];

  @action func = async () => {
    this.students = await fetch('url');
  };

  @action changeUserName(newUserName) {
    this.userFullName = newUserName;
  }
  @action AddWatchedStudentId(studentId) {
    if (!this.students.includes(studentId)) {
      this.students.push(studentId);
    }
  }
  @action AddWatchedWork(workId) {
    if (!this.workCount.includes(workId)) {
      this.workCount.push(workId);
    }
  }
}
