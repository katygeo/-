import MainStore from './MainStore';

export default {
  MainStore: new MainStore(),
};
