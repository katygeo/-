import React from 'react';
import 'antd/dist/antd.css';
import './App.css';
import Drawer, { getLinks } from './components/Drawer';
import Dashboard from './components/Dashboard';
import CourseWork from './components/Tables/CourseWork';
import LoginForm from './components/LoginForm';
import Header from './components/Header';
import { inject } from 'mobx-react';

@inject('MainStore')
class App extends React.Component {
  state = {
    isLoggedIn: false,
    navItemIndex: -1,
    navItemContent: '',
    navButtonId: 0,
    studentId: 0,
  };

  onLoginFormClick = (isLogin) => {
    this.setState({ isLoggedIn: isLogin });
  };

  onNavChange = (navItemIndex, navItemContent) => () => {
    this.setState({ navItemIndex, navItemContent });
  };

  setNavButtonId = (navButtonId, needChangeNavigator) => {
    this.setState({ navButtonId });
    if (needChangeNavigator) {
      this.setState({
        navItemIndex: getLinks().length,
      });
    }
  };
  setStudentId = (studentId) => {
    if (this.state.studentId != undefined) {
      this.state.navItemContent = <CourseWork id={studentId} />;
    }
    this.setState({ studentId });
    this.props.MainStore.AddWatchedStudentId(studentId);
  };

  render() {
    const { isLoggedIn, navItemIndex, navItemContent, studentId } = this.state;

    return (
      <div className='App'>
        <>
          {isLoggedIn ? (
            <>
              <Header />
              <Drawer
                setNavButtonId={this.setNavButtonId}
                setStudentId={this.setStudentId}
                onNavChange={this.onNavChange}
                navItemIndex={navItemIndex}
              />
              <Dashboard
                handleClick={this.onLoginFormClick}
                navItemContent={navItemContent}
              />
            </>
          ) : (
            <LoginForm handleClick={this.onLoginFormClick} />
          )}
        </>
      </div>
    );
  }
}

export default App;
